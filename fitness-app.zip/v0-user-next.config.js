/** @type {import('next').NextConfig} */
const nextConfig = {
  output: "export",
  // Set the correct base path for GitHub Pages
  // This should match your repository name
  basePath: process.env.NODE_ENV === "production" ? "/your-repo-name" : "",
  // This ensures assets are referenced correctly
  assetPrefix: process.env.NODE_ENV === "production" ? "/your-repo-name/" : "",
  images: {
    unoptimized: true,
  },
  trailingSlash: true,
}

module.exports = nextConfig

