"use client"

import Link from "next/link"
import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"

export default function DietPlanPage() {
  const router = useRouter()
  const [quizData, setQuizData] = useState(null)
  const [dietPlan, setDietPlan] = useState({
    macros: { protein: "", carbs: "", fats: "", calories: "" },
    mealPlan: [],
    highProteinFoods: [],
    sleepTips: [],
    expectedResults: "",
  })
  const [isClient, setIsClient] = useState(false)

  // Set isClient to true when component mounts
  useEffect(() => {
    setIsClient(true)
  }, [])

  // Retrieve quiz data and generate personalized plan
  useEffect(() => {
    if (isClient) {
      try {
        // Retrieve quiz data from localStorage
        const savedData = localStorage.getItem("quizData")
        if (savedData) {
          const parsedData = JSON.parse(savedData)
          setQuizData(parsedData)

          // Generate personalized diet plan based on quiz data
          generateDietPlan(parsedData)
        } else {
          // If no quiz data, redirect to quiz
          router.push("/quiz")
        }
      } catch (error) {
        console.error("Error loading quiz data:", error)
      }
    }
  }, [router, isClient])

  // Function to generate personalized diet plan based on quiz answers
  const generateDietPlan = (data) => {
    const plan = {
      macros: { protein: "", carbs: "", fats: "", calories: "" },
      mealPlan: [],
      highProteinFoods: [],
      sleepTips: [],
      expectedResults: "",
      maintenanceCalories: 0,
      deficitCalories: 0,
    }

    // Calculate maintenance calories using Mifflin-St Jeor equation
    let maintenanceCalories = 0
    let deficitCalories = 0

    if (data.weight && data.height && data.age) {
      let bmr = 0

      if (data.gender === "male") {
        // Male equation
        bmr = 10 * data.weight + 6.25 * data.height - 5 * data.age + 5
      } else if (data.gender === "female") {
        // Female equation
        bmr = 10 * data.weight + 6.25 * data.height - 5 * data.age - 161
      } else {
        // If gender not specified, use average of male and female
        const maleCalories = 10 * data.weight + 6.25 * data.height - 5 * data.age + 5
        const femaleCalories = 10 * data.weight + 6.25 * data.height - 5 * data.age - 161
        bmr = (maleCalories + femaleCalories) / 2
      }

      // Apply activity multiplier based on training days
      let activityMultiplier = 1.2 // Default to sedentary

      if (data.trainingDays === "2-3 days") {
        activityMultiplier = 1.375 // Lightly active
      } else if (data.trainingDays === "4 days") {
        activityMultiplier = 1.55 // Moderately active
      } else if (data.trainingDays === "5 days") {
        activityMultiplier = 1.65 // Between moderately and very active
      } else if (data.trainingDays === "6+ days") {
        activityMultiplier = 1.725 // Very active
      }

      maintenanceCalories = Math.round(bmr * activityMultiplier)
      deficitCalories = Math.round(maintenanceCalories * 0.8) // 20% deficit

      plan.maintenanceCalories = maintenanceCalories
      plan.deficitCalories = deficitCalories
    }

    // Calculate BMI if height and weight are provided
    let bmi = 0
    if (data.height && data.weight) {
      const heightInMeters = data.height / 100
      bmi = data.weight / (heightInMeters * heightInMeters)
    }

    // Set macros based on fitness level, BMI, and calculated calories
    if (maintenanceCalories > 0) {
      const proteinPerKg =
        data.fitnessLevel === "Beginner (0-6 months)"
          ? 1.6
          : data.fitnessLevel === "Intermediate (6-18 months)"
            ? 1.8
            : 2.0

      const dailyProteinGrams = Math.round(proteinPerKg * data.weight)
      const proteinCalories = dailyProteinGrams * 4 // 4 calories per gram of protein

      const fatPerKg = 0.8
      const dailyFatGrams = Math.round(fatPerKg * data.weight)
      const fatCalories = dailyFatGrams * 9 // 9 calories per gram of fat

      const remainingCalories = deficitCalories - proteinCalories - fatCalories
      const dailyCarbGrams = Math.round(remainingCalories / 4) // 4 calories per gram of carbs

      plan.macros = {
        protein: `${dailyProteinGrams}g (${proteinPerKg}g per kg of bodyweight)`,
        carbs: `${dailyCarbGrams}g`,
        fats: `${dailyFatGrams}g (${fatPerKg}g per kg of bodyweight)`,
        calories: `${deficitCalories} calories (20% deficit from ${maintenanceCalories} maintenance)`,
      }
    } else {
      // Fallback if we can't calculate precise calories
      plan.macros = {
        protein: `${Math.round(1.8 * data.weight)}g (1.8g per kg of bodyweight)`,
        carbs: "3-4g per kg of bodyweight",
        fats: "0.8-1g per kg of bodyweight",
        calories: "Aim for a 20% caloric deficit from maintenance",
      }
    }

    // Meal plan based on dietary preferences (keep the existing code)
    if (data.dietaryPreferences === "Vegetarian") {
      plan.mealPlan = [
        {
          meal: "Breakfast",
          options: [
            "Greek yogurt with berries and nuts",
            "Protein smoothie with plant-based protein, banana, and almond milk",
            "Tofu scramble with vegetables and whole grain toast",
          ],
        },
        {
          meal: "Lunch",
          options: [
            "Lentil and vegetable soup with whole grain bread",
            "Quinoa bowl with roasted vegetables and chickpeas",
            "Vegetarian burrito bowl with beans, rice, and vegetables",
          ],
        },
        {
          meal: "Dinner",
          options: [
            "Stir-fried tofu with vegetables and brown rice",
            "Bean and vegetable chili with a side salad",
            "Eggplant parmesan with whole wheat pasta",
          ],
        },
        {
          meal: "Snacks",
          options: ["Cottage cheese with fruit", "Protein bar", "Handful of nuts and seeds", "Edamame"],
        },
      ]

      plan.highProteinFoods = [
        "Greek yogurt",
        "Cottage cheese",
        "Eggs",
        "Tofu",
        "Tempeh",
        "Seitan",
        "Lentils",
        "Chickpeas",
        "Black beans",
        "Quinoa",
        "Nuts and seeds",
        "Plant-based protein powder",
      ]
    } else if (data.dietaryPreferences === "Dairy-free") {
      plan.mealPlan = [
        {
          meal: "Breakfast",
          options: [
            "Overnight oats with almond milk and protein powder",
            "Avocado toast with eggs",
            "Dairy-free smoothie with plant protein, banana, and coconut milk",
          ],
        },
        {
          meal: "Lunch",
          options: [
            "Grilled chicken salad with olive oil dressing",
            "Tuna wrap with vegetables",
            "Turkey and avocado sandwich on whole grain bread",
          ],
        },
        {
          meal: "Dinner",
          options: [
            "Baked salmon with sweet potato and vegetables",
            "Lean beef stir-fry with rice",
            "Chicken and vegetable curry with coconut milk",
          ],
        },
        {
          meal: "Snacks",
          options: ["Beef jerky", "Dairy-free protein shake", "Apple with almond butter", "Trail mix"],
        },
      ]

      plan.highProteinFoods = [
        "Chicken breast",
        "Turkey",
        "Lean beef",
        "Fish",
        "Eggs",
        "Tofu",
        "Lentils",
        "Chickpeas",
        "Quinoa",
        "Nuts and seeds",
        "Dairy-free protein powder",
        "Edamame",
      ]
    } else if (data.dietaryPreferences === "Gluten-free") {
      plan.mealPlan = [
        {
          meal: "Breakfast",
          options: [
            "Greek yogurt with berries and gluten-free granola",
            "Protein smoothie with banana and almond milk",
            "Eggs with vegetables and gluten-free toast",
          ],
        },
        {
          meal: "Lunch",
          options: [
            "Grilled chicken salad with quinoa",
            "Rice bowl with lean protein and vegetables",
            "Corn tortilla wraps with turkey and avocado",
          ],
        },
        {
          meal: "Dinner",
          options: [
            "Baked fish with rice and vegetables",
            "Stir-fry with gluten-free tamari sauce",
            "Grilled steak with sweet potato and salad",
          ],
        },
        {
          meal: "Snacks",
          options: ["Greek yogurt", "Protein bar (gluten-free)", "Cheese and fruit", "Hard-boiled eggs"],
        },
      ]

      plan.highProteinFoods = [
        "Chicken breast",
        "Turkey",
        "Lean beef",
        "Fish",
        "Eggs",
        "Greek yogurt",
        "Cottage cheese",
        "Quinoa",
        "Nuts and seeds",
        "Gluten-free protein powder",
        "Lentils",
        "Beans",
      ]
    } else {
      // No restrictions
      plan.mealPlan = [
        {
          meal: "Breakfast",
          options: [
            "Greek yogurt with berries and granola",
            "Protein oatmeal with banana and peanut butter",
            "Eggs with whole grain toast and avocado",
          ],
        },
        {
          meal: "Lunch",
          options: [
            "Grilled chicken sandwich on whole grain bread",
            "Tuna salad with mixed greens",
            "Turkey and vegetable wrap",
          ],
        },
        {
          meal: "Dinner",
          options: [
            "Baked salmon with brown rice and vegetables",
            "Lean beef stir-fry with noodles",
            "Chicken breast with sweet potato and broccoli",
          ],
        },
        {
          meal: "Snacks",
          options: [
            "Protein shake",
            "Greek yogurt",
            "Cottage cheese with fruit",
            "Protein bar",
            "Nuts and dried fruit",
          ],
        },
      ]

      plan.highProteinFoods = [
        "Chicken breast",
        "Turkey",
        "Lean beef",
        "Fish",
        "Eggs",
        "Greek yogurt",
        "Cottage cheese",
        "Whey protein",
        "Lentils",
        "Chickpeas",
        "Quinoa",
        "Nuts and seeds",
      ]
    }

    // Sleep and recovery tips
    plan.sleepTips = [
      "Aim for 7-9 hours of sleep per night",
      "Maintain a consistent sleep schedule",
      "Avoid screens 1 hour before bedtime",
      "Keep your bedroom cool and dark",
      "Limit caffeine after 2pm",
    ]

    // Expected results based on consistency and fitness level
    if (data.fitnessLevel === "Beginner (0-6 months)") {
      plan.expectedResults =
        "With consistent training and nutrition at a 20% caloric deficit, beginners can expect to see noticeable changes in body composition within 8-12 weeks. You may gain 1-2 pounds of muscle per month while simultaneously losing 1-2 pounds of fat per month."
    } else if (data.fitnessLevel === "Intermediate (6-18 months)") {
      plan.expectedResults =
        "At the intermediate level, progress will be slower but still significant. With a 20% caloric deficit, expect to gain 0.5-1 pound of muscle per month while losing 1-2 pounds of fat per month with proper nutrition and training."
    } else if (data.fitnessLevel === "Advanced (18+ months)") {
      plan.expectedResults =
        "Advanced trainees will see more subtle changes that occur over longer periods. With a 20% caloric deficit, focus on maintaining muscle while losing 0.5-1 pound of fat per week. Expect slower but sustainable progress."
    } else {
      plan.expectedResults =
        "With consistent adherence to your training and nutrition plan at a 20% caloric deficit, you can expect to see noticeable changes in your body composition within 2-3 months. Results vary based on genetics, consistency, and recovery."
    }

    setDietPlan(plan)
  }

  // Handle retaking the quiz
  const handleRetakeQuiz = () => {
    router.push("/quiz")
  }

  // Add the download functionality to the diet plan page
  const handleDownloadPlan = () => {
    if (!isClient) return

    try {
      // Create content for the download
      let content = "YOUR PERSONALIZED DIET PLAN\n\n"

      // Add user data
      if (quizData) {
        content += "PLAN DETAILS:\n"
        content += `Dietary Preferences: ${quizData.dietaryPreferences || "Not specified"}\n`
        content += `Fitness Level: ${quizData.fitnessLevel || "Not specified"}\n`
        content += `Training Days: ${quizData.trainingDays || "Not specified"}\n`
        if (quizData.gender) content += `Gender: ${quizData.gender}\n`
        if (quizData.weight) content += `Weight: ${quizData.weight} kg\n`
        if (quizData.height) content += `Height: ${quizData.height} cm\n`
        if (quizData.age) content += `Age: ${quizData.age}\n`
        content += "\n"
      }

      // Add macros
      content += "DAILY TARGETS:\n"
      if (dietPlan.maintenanceCalories > 0) {
        content += `Maintenance Calories: ${dietPlan.maintenanceCalories} calories\n`
        content += `Target Calories (20% deficit): ${dietPlan.deficitCalories} calories\n`
      }
      content += `Protein: ${dietPlan.macros.protein}\n`
      content += `Carbohydrates: ${dietPlan.macros.carbs}\n`
      content += `Fats: ${dietPlan.macros.fats}\n`
      if (!dietPlan.maintenanceCalories) {
        content += `Calories: ${dietPlan.macros.calories}\n`
      }
      content += "\n"

      // Add meal plan
      content += "MEAL PLAN:\n"
      dietPlan.mealPlan.forEach((meal) => {
        content += `\n${meal.meal}:\n`
        meal.options.forEach((option) => {
          content += `- ${option}\n`
        })
      })
      content += "\n"

      // Add high protein foods
      content += "HIGH PROTEIN FOODS:\n"
      dietPlan.highProteinFoods.forEach((food) => {
        content += `- ${food}\n`
      })
      content += "\n"

      // Add sleep tips
      content += "SLEEP & RECOVERY TIPS:\n"
      dietPlan.sleepTips.forEach((tip) => {
        content += `- ${tip}\n`
      })
      content += "\n"

      // Add expected results
      content += "EXPECTED RESULTS:\n"
      content += dietPlan.expectedResults

      // Create a blob and download
      const blob = new Blob([content], { type: "text/plain" })
      const url = URL.createObjectURL(blob)
      const a = document.createElement("a")
      a.href = url
      a.download = "diet-plan.txt"
      document.body.appendChild(a)
      a.click()
      document.body.removeChild(a)
      URL.revokeObjectURL(url)
    } catch (error) {
      console.error("Error downloading diet plan:", error)
      alert("There was an error downloading your diet plan. Please try again.")
    }
  }

  return (
    <div className="min-h-screen bg-lime-200 p-4">
      <div className="max-w-6xl mx-auto bg-white p-6 rounded-lg">
        <div className="bg-blue-200 rounded-full p-4 mb-6">
          <h1 className="text-center text-4xl font-extrabold">Your Personalized Diet Plan</h1>
        </div>

        <div className="flex justify-between mb-6">
          <Link
            href="/"
            className="bg-pink-400 text-black px-6 py-2 rounded-full hover:bg-pink-500 transition-colors font-bold text-lg shadow-md"
          >
            Home
          </Link>
          <Link
            href="/workout-plan"
            className="bg-yellow-300 text-black px-6 py-2 rounded-full hover:bg-yellow-400 transition-colors font-bold text-lg"
          >
            Workout plan
          </Link>
        </div>

        {quizData && (
          <div className="bg-blue-50 p-4 rounded-lg mb-6">
            <h2 className="font-bold text-xl mb-3">Your Personalized Diet Plan Based On:</h2>
            <ul className="grid grid-cols-1 md:grid-cols-2 gap-2">
              <li>
                <span className="font-medium">Dietary Preferences:</span>{" "}
                {quizData.dietaryPreferences || "Not specified"}
              </li>
              <li>
                <span className="font-medium">Fitness Level:</span> {quizData.fitnessLevel || "Not specified"}
              </li>
              <li>
                <span className="font-medium">Training Days:</span> {quizData.trainingDays || "Not specified"}
              </li>
              {quizData.gender && (
                <li>
                  <span className="font-medium">Gender:</span> {quizData.gender}
                </li>
              )}
              {quizData.weight && (
                <li>
                  <span className="font-medium">Weight:</span> {quizData.weight} kg
                </li>
              )}
              {quizData.height && (
                <li>
                  <span className="font-medium">Height:</span> {quizData.height} cm
                </li>
              )}
              {quizData.age && (
                <li>
                  <span className="font-medium">Age:</span> {quizData.age}
                </li>
              )}
            </ul>
          </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
          <div className="bg-yellow-300 p-4 rounded-lg">
            <h2 className="font-bold text-2xl mb-3">Example Diet & High Protein Recipes</h2>
            <div className="space-y-4">
              {dietPlan.mealPlan.map((meal, index) => (
                <div key={index} className="mb-3">
                  <h3 className="font-bold text-lg border-b-2 border-yellow-400 pb-1 mb-2">{meal.meal}</h3>
                  <ul className="list-disc pl-5 space-y-1">
                    {meal.options.map((option, i) => (
                      <li key={i} className="text-sm">
                        {option}
                      </li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-pink-200 p-4 rounded-lg">
            <h2 className="font-bold text-2xl mb-3">Macro-nutrient & Calorie Requirements</h2>
            <div className="space-y-3">
              <div className="bg-white p-3 rounded-lg">
                <h3 className="font-bold text-lg text-center border-b-2 border-pink-300 pb-1 mb-2">Daily Targets</h3>
                <div className="space-y-2">
                  {dietPlan.maintenanceCalories > 0 && (
                    <>
                      <p>
                        <span className="font-bold">Maintenance Calories:</span> {dietPlan.maintenanceCalories} calories
                      </p>
                      <p>
                        <span className="font-bold">Target Calories (20% deficit):</span> {dietPlan.deficitCalories}{" "}
                        calories
                      </p>
                    </>
                  )}
                  <p>
                    <span className="font-bold">Protein:</span> {dietPlan.macros.protein}
                  </p>
                  <p>
                    <span className="font-bold">Carbohydrates:</span> {dietPlan.macros.carbs}
                  </p>
                  <p>
                    <span className="font-bold">Fats:</span> {dietPlan.macros.fats}
                  </p>
                  {!dietPlan.maintenanceCalories && (
                    <p>
                      <span className="font-medium">Calories:</span> {dietPlan.macros.calories}
                    </p>
                  )}
                </div>
              </div>

              <div className="bg-white p-3 rounded-lg mt-4">
                <h3 className="font-medium text-center border-b border-pink-300 pb-1 mb-2">High Protein Foods</h3>
                <div className="grid grid-cols-2 gap-1">
                  {dietPlan.highProteinFoods.map((food, index) => (
                    <div key={index} className="text-sm p-1">
                      {food}
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
          <div className="bg-blue-200 p-4 rounded-lg flex flex-col justify-between">
            <h2 className="font-medium text-xl mb-3">Infographic</h2>
            <div className="flex-grow flex items-center justify-center">
              <div className="bg-white p-4 rounded-lg w-full">
                <h3 className="font-medium text-center mb-3">Body Recomposition Nutrition Pyramid</h3>
                <div className="space-y-2">
                  <div className="bg-red-100 p-2 text-center rounded-t-lg">Supplements (Optional)</div>
                  <div className="bg-orange-100 p-2 text-center">Meal Timing</div>
                  <div className="bg-yellow-100 p-2 text-center">Food Quality</div>
                  <div className="bg-green-100 p-2 text-center">Macronutrients</div>
                  <div className="bg-blue-100 p-2 text-center rounded-b-lg">Caloric Balance</div>
                </div>
                <p className="text-xs text-center mt-2">Focus on the foundation first (bottom to top)</p>
              </div>
            </div>
          </div>

          <div className="bg-lime-200 p-4 rounded-lg">
            <h2 className="font-medium text-xl mb-3">Sleep & Recovery Tips and Expected Results</h2>
            <div className="mb-4">
              <h3 className="font-medium border-b border-lime-300 pb-1 mb-2">Sleep & Recovery</h3>
              <ul className="list-disc pl-5 space-y-1">
                {dietPlan.sleepTips.map((tip, index) => (
                  <li key={index} className="text-sm">
                    {tip}
                  </li>
                ))}
              </ul>
            </div>

            <div>
              <h3 className="font-medium border-b border-lime-300 pb-1 mb-2">Expected Results</h3>
              <p className="text-sm">{dietPlan.expectedResults}</p>
            </div>
          </div>
        </div>

        <div className="flex flex-col md:flex-row justify-center gap-3">
          <button
            onClick={handleDownloadPlan}
            className="bg-blue-400 text-black px-8 py-3 rounded-full text-center hover:bg-blue-500 transition-colors font-bold text-lg shadow-md w-full md:w-1/3"
          >
            Download Plan
          </button>
          <button
            onClick={handleRetakeQuiz}
            className="bg-pink-400 text-black px-8 py-3 rounded-full text-center hover:bg-pink-500 transition-colors font-bold text-lg shadow-md w-full md:w-1/3"
          >
            Retake the quiz
          </button>
        </div>
      </div>
    </div>
  )
}

