"use client"

import Link from "next/link"
import { useState } from "react"

export default function HomePage() {
  // Add state for images to handle loading errors
  const [imagesLoaded, setImagesLoaded] = useState({
    infographic1: true,
    bodyComposition: true,
    recompVsWeight: true,
    coupleWorkout: true,
    transformation: true,
    highProtein: true,
  })

  // Handle image loading errors
  const handleImageError = (imageName) => {
    setImagesLoaded((prev) => ({
      ...prev,
      [imageName]: false,
    }))
  }

  return (
    <div className="min-h-screen bg-lime-200 p-4">
      <div className="max-w-6xl mx-auto bg-white p-6 rounded-lg">
        <div className="bg-blue-200 rounded-full p-4 mb-4">
          <h1 className="text-center text-4xl font-extrabold text-black">Homepage</h1>
        </div>

        <div className="flex justify-center mb-4">
          <Link
            href="/quiz"
            className="bg-pink-300 text-black px-8 py-3 rounded-full font-bold text-lg hover:bg-pink-400 transition-colors shadow-md"
          >
            Generate your optimal recomp plan now!
          </Link>
        </div>

        <div className="flex flex-col md:flex-row gap-4 mb-6">
          <div className="w-full md:w-1/4 bg-lime-200 flex items-center justify-center overflow-hidden">
            {imagesLoaded.infographic1 ? (
              <img
                src="https://images.squarespace-cdn.com/content/v1/5e419cdc97af032560004b99/6bcdcb3d-c505-453c-9995-2e4f1824d414/Exercise+Benefits+Infographic+compressed.png"
                alt="Health Benefits of Exercise Infographic"
                className="w-full h-auto"
                onError={() => handleImageError("infographic1")}
              />
            ) : (
              <div className="w-full aspect-[3/8] bg-blue-100 flex items-center justify-center p-4 text-center">
                <p className="font-medium">Exercise Benefits Infographic</p>
              </div>
            )}
          </div>

          <div className="w-full md:w-3/4">
            <div className="bg-blue-200 p-4 mb-4 rounded-lg">
              <h2 className="text-2xl font-bold mb-3 text-black">Introductory message</h2>
              <p className="text-base font-medium mb-2">
                Welcome to TeenRecomp, your ultimate resource for achieving the perfect body composition during your
                teenage years! Body recomposition—the process of building muscle while simultaneously losing fat—is
                particularly effective during adolescence due to your naturally elevated hormone levels and faster
                recovery capabilities.
              </p>
              <p className="text-base font-medium mb-2">
                As a teen, your body is in a unique growth phase that creates an optimal environment for transformation.
                Unlike adults who often need to choose between bulking and cutting cycles, your youthful metabolism and
                hormonal profile give you the extraordinary ability to reshape your physique more efficiently. This
                means you can develop lean muscle and reduce body fat percentage at the same time—something that becomes
                increasingly difficult with age.
              </p>
              <p className="text-base font-medium">
                Our science-backed approach combines age-appropriate nutrition strategies with progressive resistance
                training, designed specifically for developing bodies. We emphasize proper form, adequate recovery, and
                sustainable habits that support both your physical development and overall health. Remember, the goal
                isn't just aesthetic—it's about building strength, confidence, and healthy habits that will serve you
                throughout your life. Whether you're an athlete looking to improve performance or simply want to feel
                more confident in your body, our personalized recomp plans will guide you safely toward your goals.
              </p>
            </div>

            <div className="flex flex-col md:flex-row gap-4">
              <div className="w-full md:w-1/2">
                <div className="text-center mb-1 font-bold text-xl">Body Recomposition for Teenagers</div>
                <div className="bg-gradient-to-b from-blue-100 to-blue-200 rounded-lg overflow-hidden mb-1 relative group cursor-pointer">
                  <div className="aspect-video flex items-center justify-center bg-blue-100 p-4">
                    <div className="text-center">
                      <div className="text-4xl mb-2">▶️</div>
                      <p className="font-medium">Video: Teen Body Recomposition Guide</p>
                    </div>
                  </div>
                  <div className="absolute inset-0 flex items-center justify-center bg-black bg-opacity-10 group-hover:bg-opacity-0 transition-all"></div>
                </div>
                <a
                  href="https://youtu.be/8ZAQ80DYDDw"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="bg-blue-200 text-center p-2 rounded-lg hover:bg-blue-300 transition-colors cursor-pointer block font-bold text-lg"
                >
                  Watch Full Video
                </a>
              </div>

              <div className="w-full md:w-1/2 bg-lime-200 flex items-center justify-center overflow-hidden">
                {imagesLoaded.bodyComposition ? (
                  <img
                    src="https://myvitalmetrics.com/wp-content/uploads/2024/08/Body-Composition-Myths-Banner-595xh.jpg"
                    alt="Body Composition Myths"
                    className="w-full h-auto"
                    onError={() => handleImageError("bodyComposition")}
                  />
                ) : (
                  <div className="w-full aspect-[3/1] bg-blue-100 flex items-center justify-center p-4 text-center">
                    <p className="font-medium">Body Composition Myths</p>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="flex flex-col items-center">
            <a
              href="https://www.healthline.com/nutrition/body-recomposition"
              target="_blank"
              rel="noopener noreferrer"
              className="w-full"
            >
              <div className="bg-blue-200 w-full flex items-center justify-center mb-1 overflow-hidden">
                {imagesLoaded.recompVsWeight ? (
                  <img
                    src="https://welltech.com/wp-content/uploads/2022/08/body-recomposition-vs-weight-loss.jpg"
                    alt="Body Recomposition vs Weight Loss"
                    className="w-full h-auto"
                    onError={() => handleImageError("recompVsWeight")}
                  />
                ) : (
                  <div className="w-full aspect-[5/3] bg-blue-100 flex items-center justify-center p-4 text-center">
                    <p className="font-medium">Body Recomposition vs Weight Loss</p>
                  </div>
                )}
              </div>
              <div className="font-bold text-lg text-center hover:underline">
                How to Lose Fat and Gain Muscle for Body Recomposition
              </div>
            </a>
          </div>

          <div className="flex flex-col items-center">
            <a
              href="https://getshifted.com/blogs/lab-notes/60-day-body-recomposition-meal-plan-workouts-lose-fat-two-months"
              target="_blank"
              rel="noopener noreferrer"
              className="w-full"
            >
              <div className="bg-blue-200 w-full flex items-center justify-center mb-1 overflow-hidden">
                {imagesLoaded.coupleWorkout ? (
                  <img
                    src="https://www.nutrishopusa.com/cdn/shop/articles/couple-workout_9e196187-3781-4c80-a9e8-4cf38076878b.png?v=1703883843"
                    alt="Couple Workout for Body Recomposition"
                    className="w-full h-auto"
                    onError={() => handleImageError("coupleWorkout")}
                  />
                ) : (
                  <div className="w-full aspect-[5/3] bg-blue-100 flex items-center justify-center p-4 text-center">
                    <p className="font-medium">Couple Workout for Body Recomposition</p>
                  </div>
                )}
              </div>
              <div className="font-bold text-lg text-center hover:underline">
                60-Day Body Recomposition Meal Plan & Workouts
              </div>
            </a>
          </div>

          <div className="flex flex-col items-center">
            <a
              href="https://hevycoach.com/glossary/body-recomposition/"
              target="_blank"
              rel="noopener noreferrer"
              className="w-full"
            >
              <div className="bg-blue-200 w-full flex items-center justify-center mb-1 overflow-hidden">
                {imagesLoaded.transformation ? (
                  <img
                    src="https://builtwithscience.com/wp-content/uploads/2018/02/Screen-Shot-2018-02-24-at-10.14.24-AM-e1568945363916.png"
                    alt="Body Recomposition Transformation"
                    className="w-full h-auto"
                    onError={() => handleImageError("transformation")}
                  />
                ) : (
                  <div className="w-full aspect-[5/3] bg-blue-100 flex items-center justify-center p-4 text-center">
                    <p className="font-medium">Body Recomposition Transformation</p>
                  </div>
                )}
              </div>
              <div className="font-bold text-lg text-center hover:underline">
                Body Recomposition: What Is It and How to Achieve It
              </div>
            </a>
          </div>

          <div className="flex flex-col items-center">
            <a
              href="https://www.healthline.com/nutrition/high-protein-foods"
              target="_blank"
              rel="noopener noreferrer"
              className="w-full"
            >
              <div className="bg-blue-200 w-full flex items-center justify-center mb-1 overflow-hidden">
                {imagesLoaded.highProtein ? (
                  <img
                    src="https://www.blendtec.com/cdn/shop/articles/Screen_Shot_2024-07-18_at_9.22.47_AM_1000x.png?v=1721312831"
                    alt="High Protein Foods"
                    className="w-full h-auto"
                    onError={() => handleImageError("highProtein")}
                  />
                ) : (
                  <div className="w-full aspect-[5/3] bg-blue-100 flex items-center justify-center p-4 text-center">
                    <p className="font-medium">High Protein Foods</p>
                  </div>
                )}
              </div>
              <div className="font-bold text-lg text-center hover:underline">
                High-Protein Foods for Optimal Body Recomposition
              </div>
            </a>
          </div>
        </div>
      </div>
    </div>
  )
}

