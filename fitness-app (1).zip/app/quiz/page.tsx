"use client"

import Link from "next/link"
import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"

export default function QuizPage() {
  const router = useRouter()
  const [formData, setFormData] = useState({
    equipmentAccess: "",
    fitnessLevel: "",
    trainingEnvironment: "",
    trainingDays: "",
    dietaryPreferences: "",
    age: "",
    weight: "",
    height: "",
    sleepHours: "",
    gender: "",
  })
  const [isClient, setIsClient] = useState(false)

  // Set isClient to true when component mounts
  useEffect(() => {
    setIsClient(true)
  }, [])

  // Load data from localStorage on initial render
  useEffect(() => {
    if (isClient) {
      try {
        const savedData = localStorage.getItem("quizData")
        if (savedData) {
          setFormData(JSON.parse(savedData))
        }
      } catch (error) {
        console.error("Error loading quiz data:", error)
      }
    }
  }, [isClient])

  // Handle text input changes
  const handleInputChange = (e) => {
    const { name, value } = e.target
    setFormData((prevData) => {
      const newData = { ...prevData, [name]: value }
      // Save to localStorage after each change
      if (isClient) {
        try {
          localStorage.setItem("quizData", JSON.stringify(newData))
        } catch (error) {
          console.error("Error saving quiz data:", error)
        }
      }
      return newData
    })
  }

  // Handle radio button changes
  const handleRadioChange = (name, value) => {
    setFormData((prevData) => {
      const newData = { ...prevData, [name]: value }
      // Save to localStorage after each change
      if (isClient) {
        try {
          localStorage.setItem("quizData", JSON.stringify(newData))
        } catch (error) {
          console.error("Error saving quiz data:", error)
        }
      }
      return newData
    })
  }

  // Handle form submission
  const handleSubmit = (e) => {
    e.preventDefault()
    // Save final data to localStorage
    if (isClient) {
      try {
        localStorage.setItem("quizData", JSON.stringify(formData))
      } catch (error) {
        console.error("Error saving quiz data:", error)
      }
    }
    // Redirect to workout plan page
    router.push("/workout-plan")
  }

  return (
    <div className="min-h-screen bg-lime-200 p-4">
      <div className="max-w-6xl mx-auto bg-white p-6 rounded-lg">
        <div className="bg-blue-200 rounded-full p-4 mb-6">
          <h1 className="text-center text-2xl font-extrabold">Help us make your personalised recomposition plan</h1>
        </div>

        <div className="flex justify-center mb-6">
          <Link
            href="/"
            className="bg-blue-300 text-black px-6 py-2 rounded-full hover:bg-blue-400 transition-colors font-bold text-lg shadow-md"
          >
            Home
          </Link>
        </div>

        <form onSubmit={handleSubmit} className="mb-6 space-y-8">
          {/* Question 1: Equipment Access */}
          <div className="mb-8 border-b border-gray-200 pb-6">
            <div className="mb-3">
              <h3 className="font-bold text-xl">Question 1: What equipment do you have access to?</h3>
              <p className="text-base text-gray-700 mb-3 font-medium">
                This helps us design workouts with the right equipment for your recomposition plan.
              </p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              {[
                "Bodyweight only",
                "Dumbbells & resistance bands",
                "Home gym with basic equipment",
                "Full commercial gym",
              ].map((option) => (
                <div key={option} className="flex items-center space-x-2">
                  <input
                    type="radio"
                    id={`equipment-${option}`}
                    name="equipmentAccess"
                    value={option}
                    checked={formData.equipmentAccess === option}
                    onChange={() => handleRadioChange("equipmentAccess", option)}
                    className="h-5 w-5 cursor-pointer"
                  />
                  <label htmlFor={`equipment-${option}`} className="cursor-pointer">
                    {option}
                  </label>
                </div>
              ))}
            </div>
          </div>

          {/* Question 2: Fitness Level */}
          <div className="mb-8 border-b border-gray-200 pb-6">
            <div className="mb-3">
              <h3 className="font-bold text-xl">Question 2: What is your current fitness level?</h3>
              <p className="text-base text-gray-700 mb-3 font-medium">
                This helps us determine the intensity of your workouts.
              </p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              {[
                "Beginner (0-6 months)",
                "Intermediate (6-18 months)",
                "Advanced (18+ months)",
                "Athletic background",
              ].map((option) => (
                <div key={option} className="flex items-center space-x-2">
                  <input
                    type="radio"
                    id={`fitness-${option}`}
                    name="fitnessLevel"
                    value={option}
                    checked={formData.fitnessLevel === option}
                    onChange={() => handleRadioChange("fitnessLevel", option)}
                    className="h-5 w-5 cursor-pointer"
                  />
                  <label htmlFor={`fitness-${option}`} className="cursor-pointer">
                    {option}
                  </label>
                </div>
              ))}
            </div>
          </div>

          {/* Question 3: Training Environment */}
          <div className="mb-8 border-b border-gray-200 pb-6">
            <div className="mb-3">
              <h3 className="font-bold text-xl">Question 3: Where do you typically train?</h3>
              <p className="text-base text-gray-700 mb-3 font-medium">This helps us tailor your workout environment.</p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              {["At home", "School gym", "Commercial gym", "Outdoors/park"].map((option) => (
                <div key={option} className="flex items-center space-x-2">
                  <input
                    type="radio"
                    id={`environment-${option}`}
                    name="trainingEnvironment"
                    value={option}
                    checked={formData.trainingEnvironment === option}
                    onChange={() => handleRadioChange("trainingEnvironment", option)}
                    className="h-5 w-5 cursor-pointer"
                  />
                  <label htmlFor={`environment-${option}`} className="cursor-pointer">
                    {option}
                  </label>
                </div>
              ))}
            </div>
          </div>

          {/* Question 4: Training Days */}
          <div className="mb-8 border-b border-gray-200 pb-6">
            <div className="mb-3">
              <h3 className="font-bold text-xl">Question 4: How many days per week can you train?</h3>
              <p className="text-base text-gray-700 mb-3 font-medium">
                This helps us create a realistic training schedule.
              </p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              {["2-3 days", "4 days", "5 days", "6+ days"].map((option) => (
                <div key={option} className="flex items-center space-x-2">
                  <input
                    type="radio"
                    id={`days-${option}`}
                    name="trainingDays"
                    value={option}
                    checked={formData.trainingDays === option}
                    onChange={() => handleRadioChange("trainingDays", option)}
                    className="h-5 w-5 cursor-pointer"
                  />
                  <label htmlFor={`days-${option}`} className="cursor-pointer">
                    {option}
                  </label>
                </div>
              ))}
            </div>
          </div>

          {/* Question 5: Dietary Preferences */}
          <div className="mb-8 border-b border-gray-200 pb-6">
            <div className="mb-3">
              <h3 className="font-bold text-xl">Question 5: Do you have any dietary preferences or restrictions?</h3>
              <p className="text-base text-gray-700 mb-3 font-medium">This helps us customize your nutrition plan.</p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              {["No restrictions", "Vegetarian", "Dairy-free", "Gluten-free"].map((option) => (
                <div key={option} className="flex items-center space-x-2">
                  <input
                    type="radio"
                    id={`diet-${option}`}
                    name="dietaryPreferences"
                    value={option}
                    checked={formData.dietaryPreferences === option}
                    onChange={() => handleRadioChange("dietaryPreferences", option)}
                    className="h-5 w-5 cursor-pointer"
                  />
                  <label htmlFor={`diet-${option}`} className="cursor-pointer">
                    {option}
                  </label>
                </div>
              ))}
            </div>
          </div>

          {/* Additional Information */}
          <div className="mb-8 border-b border-gray-200 pb-6">
            <div className="mb-3">
              <h3 className="font-bold text-xl">Additional Information</h3>
              <p className="text-base text-gray-700 mb-3 font-medium">
                These details help us personalize your plan further.
              </p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-base font-bold mb-1">Age</label>
                <input
                  type="number"
                  name="age"
                  value={formData.age}
                  onChange={handleInputChange}
                  placeholder="Enter your age"
                  className="w-full p-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
              <div>
                <label className="block text-base font-bold mb-1">Weight (kg)</label>
                <input
                  type="number"
                  name="weight"
                  value={formData.weight}
                  onChange={handleInputChange}
                  placeholder="Enter your weight in kg"
                  className="w-full p-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
              <div>
                <label className="block text-base font-bold mb-1">Height (cm)</label>
                <input
                  type="number"
                  name="height"
                  value={formData.height}
                  onChange={handleInputChange}
                  placeholder="Enter your height in cm"
                  className="w-full p-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
              <div>
                <label className="block text-base font-bold mb-1">Average Sleep (hours)</label>
                <input
                  type="number"
                  name="sleepHours"
                  value={formData.sleepHours}
                  onChange={handleInputChange}
                  placeholder="Hours of sleep per night"
                  className="w-full p-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
            </div>

            <div className="mb-4">
              <label className="block text-base font-bold mb-1">Gender (for calorie calculations)</label>
              <div className="flex space-x-4">
                <div className="flex items-center space-x-2">
                  <input
                    type="radio"
                    id="gender-male"
                    name="gender"
                    value="male"
                    checked={formData.gender === "male"}
                    onChange={() => handleRadioChange("gender", "male")}
                    className="h-5 w-5 cursor-pointer"
                  />
                  <label htmlFor="gender-male" className="cursor-pointer">
                    Male
                  </label>
                </div>
                <div className="flex items-center space-x-2">
                  <input
                    type="radio"
                    id="gender-female"
                    name="gender"
                    value="female"
                    checked={formData.gender === "female"}
                    onChange={() => handleRadioChange("gender", "female")}
                    className="h-5 w-5 cursor-pointer"
                  />
                  <label htmlFor="gender-female" className="cursor-pointer">
                    Female
                  </label>
                </div>
              </div>
            </div>
          </div>

          <div className="flex justify-center">
            <button
              type="submit"
              className="bg-pink-400 text-black px-8 py-3 rounded-full text-xl font-bold hover:bg-pink-500 transition-colors shadow-md"
            >
              Generate My Plan
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}

